﻿//using System;
//using System.Data.SqlClient;
//using System.Collections.Generic;

//namespace Console_Hexaware
//{
//    internal class Assignment
//    {
//        static void Main()
//        {
//            SqlConnection con = new SqlConnection("Server=LAPTOP-D19876AQ;Initial Catalog=AssignmentDB;Integrated Security=True");
//            con.Open();
//            Console.WriteLine("Connection is successful.\n");

//            // Task 1: Control Flow Statements

//            // 1. Order Delivery Status
//            Console.Write("Enter Courier ID for delivery status: ");
//            int CourierID = int.Parse(Console.ReadLine());

//            SqlCommand cmdStatus = new SqlCommand("SELECT Status FROM Courier WHERE CourierID = @CourierID", con);
//            cmdStatus.Parameters.AddWithValue("@CourierID", CourierID);

//            object resultStatus = cmdStatus.ExecuteScalar();
//            if (resultStatus != null)
//            {
//                string status = resultStatus.ToString();
//                if (status.Equals("Delivered", StringComparison.OrdinalIgnoreCase))
//                    Console.WriteLine("The order has been delivered.");
//                else if (status.Equals("Processing", StringComparison.OrdinalIgnoreCase))
//                    Console.WriteLine("The order is being processed.");
//                else if (status.Equals("Cancelled", StringComparison.OrdinalIgnoreCase))
//                    Console.WriteLine("The order was cancelled.");
//                else
//                    Console.WriteLine("Unknown status.");
//            }
//            else
//            {
//                Console.WriteLine("Order ID not found.");
//            }

//            // 2. Parcel Weight Category
//            Console.Write("\nEnter Courier ID for weight check: ");
//            int courierId = int.Parse(Console.ReadLine());

//            SqlCommand cmdWeight = new SqlCommand("SELECT Weight FROM Courier WHERE CourierID = @cid", con);
//            cmdWeight.Parameters.AddWithValue("@cid", courierId);

//            object resultWeight = cmdWeight.ExecuteScalar();
//            if (resultWeight != null)
//            {
//                double weight = Convert.ToDouble(resultWeight);
//                string category = (weight < 1) ? "Light" : (weight <= 5) ? "Medium" : "Heavy";
//                Console.WriteLine($"Courier weight: {weight} kg\nCategory: {category}");
//            }
//            else
//            {
//                Console.WriteLine("Courier ID not found.");
//            }

//            // 3. User Authentication
//            Console.Write("\nEnter Email: ");
//            string email = Console.ReadLine();
//            Console.Write("Enter Password: ");
//            string password = Console.ReadLine();

//            SqlCommand empCmd = new SqlCommand("SELECT COUNT(*) FROM Employee WHERE Email = @empEmail", con);
//            empCmd.Parameters.AddWithValue("@empEmail", email);
//            int empCount = (int)empCmd.ExecuteScalar();

//            SqlCommand userCmd = new SqlCommand("SELECT COUNT(*) FROM [User] WHERE Email = @userEmail AND Password = @userPass", con);
//            userCmd.Parameters.AddWithValue("@userEmail", email);
//            userCmd.Parameters.AddWithValue("@userPass", password);
//            int userCount = (int)userCmd.ExecuteScalar();

//            if (empCount > 0)
//                Console.WriteLine("Welcome, Employee!");
//            else if (userCount > 0)
//                Console.WriteLine("Welcome, Customer!");
//            else
//                Console.WriteLine("Invalid login!");

//            // 4. Assigning Couriers to Shipments
//            Console.Write("\nEnter number of delivery boys to evaluate: ");
//            int n = int.Parse(Console.ReadLine());

//            string[] deliveryBoyNames = new string[n];
//            int[] proximity = new int[n];
//            int[] load = new int[n];

//            for (int i = 0; i < n; i++)
//            {
//                Console.Write($"\nEnter Delivery Boy Name #{i + 1}: ");
//                string name = Console.ReadLine();

//                SqlCommand empQuery = new SqlCommand("SELECT EmployeeID FROM Employee WHERE Name = @name AND Role = 'Delivery Boy'", con);
//                empQuery.Parameters.AddWithValue("@name", name);
//                object empIdObj = empQuery.ExecuteScalar();

//                if (empIdObj == null)
//                {
//                    Console.WriteLine("No such delivery boy found. Try again.");
//                    i--;
//                    continue;
//                }

//                int empId = Convert.ToInt32(empIdObj);
//                deliveryBoyNames[i] = name;

//                Console.Write("Enter Proximity (in km): ");
//                proximity[i] = int.Parse(Console.ReadLine());

//                SqlCommand loadCmd = new SqlCommand("SELECT COUNT(*) FROM Courier WHERE DeliveredByEmployeeID = @eid", con);
//                loadCmd.Parameters.AddWithValue("@eid", empId);
//                load[i] = (int)loadCmd.ExecuteScalar();
//            }

//            int bestIndex = 0;
//            for (int i = 1; i < n; i++)
//            {
//                if (proximity[i] < proximity[bestIndex] ||
//                    (proximity[i] == proximity[bestIndex] && load[i] < load[bestIndex]))
//                {
//                    bestIndex = i;
//                }
//            }

//            Console.WriteLine($"\nCourier assigned: {deliveryBoyNames[bestIndex]}\nProximity: {proximity[bestIndex]} km, Load: {load[bestIndex]} parcels");

//            // Task 2: Loops and Iteration

//            // 5. Display Orders of a Customer
//            Console.Write("\nEnter customer name to view orders: ");
//            string customerName = Console.ReadLine();

//            SqlCommand getUserIdCmd = new SqlCommand("SELECT UserID FROM [User] WHERE Name = @name", con);
//            getUserIdCmd.Parameters.AddWithValue("@name", customerName);
//            object userIdObj = getUserIdCmd.ExecuteScalar();

//            if (userIdObj == null)
//            {
//                Console.WriteLine("Customer not found.");
//            }
//            else
//            {
//                int userId = Convert.ToInt32(userIdObj);

//                SqlCommand getOrdersCmd = new SqlCommand("SELECT CourierID, TrackingNumber, Status, CreatedDate FROM Courier WHERE UserID = @uid", con);
//                getOrdersCmd.Parameters.AddWithValue("@uid", userId);

//                SqlDataReader orderReader = getOrdersCmd.ExecuteReader();
//                int count = 0;
//                Console.WriteLine("\nOrders:");
//                while (orderReader.Read())
//                {
//                    Console.WriteLine($"Order {++count}: ID = {orderReader["CourierID"]}, Tracking = {orderReader["TrackingNumber"]}, Status = {orderReader["Status"]}, Date = {((DateTime)orderReader["CreatedDate"]).ToShortDateString()}");
//                }
//                orderReader.Close();

//                if (count == 0) Console.WriteLine("No orders found.");
//            }

//            // 6. Real-time Courier Location
//            Console.Write("\nEnter Courier ID to track location: ");
//            int trackId = int.Parse(Console.ReadLine());

//            SqlCommand createdDateCmd = new SqlCommand("SELECT CreatedDate FROM Courier WHERE CourierID = @cid", con);
//            createdDateCmd.Parameters.AddWithValue("@cid", trackId);
//            object createdDateObj = createdDateCmd.ExecuteScalar();

//            if (createdDateObj != null)
//            {
//                DateTime createdDate = Convert.ToDateTime(createdDateObj);
//                int daysPassed = (DateTime.Today - createdDate).Days;

//                string location = (daysPassed <= 2) ? "In Warehouse" :
//                                  (daysPassed < 5) ? "In Transit" :
//                                  (daysPassed < 7) ? "Near Destination" : "Delivered";

//                Console.WriteLine($"Days since order placed: {daysPassed}\nParcel Status: {location}");
//            }
//            else
//            {
//                Console.WriteLine("Courier not found.");
//            }

//            // Task 3: Arrays and Data Structures

//            // 7. Tracking History (Array)
//            Console.Write("\nEnter number of location updates: ");
//            int updates = int.Parse(Console.ReadLine());
//            string[] trackingHistory = new string[updates];
//            for (int i = 0; i < updates; i++)
//            {
//                Console.Write($"Enter location update #{i + 1}: ");
//                trackingHistory[i] = Console.ReadLine();
//            }
//            Console.WriteLine("\nTracking History:");
//            for (int i = 0; i < trackingHistory.Length; i++)
//            {
//                Console.WriteLine($"Update {i + 1}: {trackingHistory[i]}");
//            }

//            // 8. Nearest Available Courier
//            SqlCommand availableCourierCmd = new SqlCommand("SELECT EmployeeID, Name FROM Employee WHERE Role = 'Delivery Boy'", con);
//            SqlDataReader availableReader = availableCourierCmd.ExecuteReader();
//            List<int> courierIds = new List<int>();
//            List<string> courierNames = new List<string>();

//            while (availableReader.Read())
//            {
//                courierIds.Add((int)availableReader["EmployeeID"]);
//                courierNames.Add(availableReader["Name"].ToString());
//            }
//            availableReader.Close();

//            int[] dist = new int[courierIds.Count];
//            int[] currentLoad = new int[courierIds.Count];

//            for (int i = 0; i < courierIds.Count; i++)
//            {
//                Console.Write($"Enter distance for {courierNames[i]}: ");
//                dist[i] = int.Parse(Console.ReadLine());

//                SqlCommand getLoad = new SqlCommand("SELECT COUNT(*) FROM Courier WHERE DeliveredByEmployeeID = @eid", con);
//                getLoad.Parameters.AddWithValue("@eid", courierIds[i]);
//                currentLoad[i] = (int)getLoad.ExecuteScalar();
//            }

//            int bestCourier = 0;
//            for (int i = 1; i < courierIds.Count; i++)
//            {
//                if (dist[i] < dist[bestCourier] ||
//                   (dist[i] == dist[bestCourier] && currentLoad[i] < currentLoad[bestCourier]))
//                {
//                    bestCourier = i;
//                }
//            }

//            Console.WriteLine($"\nNearest Available Courier: {courierNames[bestCourier]} ({dist[bestCourier]} km away, Load: {currentLoad[bestCourier]})");

//            // Task 4:Strings,2d Arrays, user defined functions,Hashmap  
//            // 9. 2D Array - Parcel Tracking
//            string[,] parcels = {
//                { "TRK123", "In Transit" },
//                { "TRK456", "Out for Delivery" },
//                { "TRK789", "Delivered" }
//            };
//            Console.Write("\nEnter Tracking Number to check status: ");
//            string trackNum = Console.ReadLine();
//            bool isFound = false;

//            for (int i = 0; i < parcels.GetLength(0); i++)
//            {
//                if (parcels[i, 0].Equals(trackNum, StringComparison.OrdinalIgnoreCase))
//                {
//                    Console.WriteLine($"Status for {trackNum}: {parcels[i, 1]}");
//                    isFound = true;
//                    break;
//                }
//            }
//            if (!isFound)
//                Console.WriteLine("Tracking number not found.");

//            con.Close();
//        }
//    }
//}


//// Created a new class and Main here so comment the above code to execute the below code.
//using System;
//using System.Collections.Generic;
//using System.Data.SqlClient;
//using System.Globalization;
//using System.Text.RegularExpressions;

//class Program
//{
//    static string connectionString = "Server=LAPTOP-D19876AQ;Initial Catalog=AssignmentDB;Integrated Security=True";

//    static bool Validate(string data, string detailType)
//    {
//        //Regex (short for Regular Expression) is a pattern-matching syntax used to search, validate,
//        //or extract data from strings — like names, emails, phone numbers, etc.
//        switch (detailType.ToLower())
//        {
//            case "name":
//                return Regex.IsMatch(data, @"^[A-Z][a-zA-Z\s]*$");
//            case "address":
//                return Regex.IsMatch(data, @"^[a-zA-Z0-9\s,.-]+$");
//            case "phone":
//                return Regex.IsMatch(data, @"^\d{3}-\d{3}-\d{4}$");
//            default:
//                return false;
//        }
//    }

//    static string FormatAddress(string street, string city, string state, string zipCode)
//    {
//        TextInfo textInfo = CultureInfo.CurrentCulture.TextInfo;
//        street = textInfo.ToTitleCase(street.ToLower());
//        city = textInfo.ToTitleCase(city.ToLower());
//        state = state.ToUpper();
//        zipCode = zipCode.PadLeft(5, '0');
//        return $"{street}, {city}, {state} - {zipCode}";
//    }

//    static string GenerateEmail(string name, string orderNo, string address, DateTime orderDate, DateTime deliveryDate)
//    {
//        return $"Hello {name},\n\n" +
//               $"Your order (#{orderNo}) has been placed successfully.\n" +
//               $"Delivery Address: {address}\n" +
//               $" Ordered Date: {orderDate:dd MMM yyyy}\n" +
//               $"Expected Delivery Date: {deliveryDate:dd MMM yyyy}\n\n" +
//               $"Thank you for using our courier service!";
//    }

//    static double CalculateShippingCost(double distance, double weight)
//    {
//        double baseRate = 5.0;
//        double distanceRate = 2.0;
//        double weightRate = 3.0;
//        return baseRate + (distance * distanceRate) + (weight * weightRate);
//    }

//    static string GeneratePassword(int length)
//    {
//        string upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
//        string lower = "abcdefghijklmnopqrstuvwxyz";
//        string digits = "0123456789";
//        string special = "!@#$%^&*";
//        string all = upper + lower + digits + special;
//        Random rand = new Random();
//        char[] password = new char[length];

//        for (int i = 0; i < length; i++)
//        {
//            password[i] = all[rand.Next(all.Length)];
//        }

//        return new string(password);
//    }

//    static void Main()
//    {
//        SqlConnection con = new SqlConnection(connectionString);
//        con.Open();

//        // 10. Customer Data Validation

//        Console.Write("\nEnter detail type to validate (name, address, phone): ");
//        string type = Console.ReadLine().ToLower();

//        Console.Write("Enter the value to check in database: ");
//        string value = Console.ReadLine();

//        string query = "";
//        switch (type)
//        {
//            case "name":
//                query = "SELECT COUNT(*) FROM [User] WHERE Name = @val";
//                break;
//            case "address":
//                query = "SELECT COUNT(*) FROM [User] WHERE Address = @val";
//                break;
//            case "phone":
//                query = "SELECT COUNT(*) FROM [User] WHERE ContactNumber = @val";
//                break;
//            default:
//                Console.WriteLine(" Invalid detail type.");
//                break;
//        }

//        if (!string.IsNullOrEmpty(query))
//        {
//            SqlCommand cmd = new SqlCommand(query, con);
//            cmd.Parameters.AddWithValue("@val", value);
//            int count = (int)cmd.ExecuteScalar();

//            if (count > 0)
//                Console.WriteLine($" Valid {type} (found in database)");
//            else
//                Console.WriteLine($" Invalid {type} (not found in database)");
//        }

//        // 11. Address Formatting
//        Console.Write("\nEnter Street: ");
//        string street = Console.ReadLine();
//        Console.Write("Enter City: ");
//        string city = Console.ReadLine();
//        Console.Write("Enter State (e.g., CA): ");
//        string state = Console.ReadLine();
//        Console.Write("Enter Zip Code: ");
//        string zip = Console.ReadLine();
//        Console.WriteLine($"📬 Formatted Address: {FormatAddress(street, city, state, zip)}");

//        // 12. Order Confirmation Email
//        Console.Write("\nEnter Customer Name: ");
//        string name = Console.ReadLine();
//        Console.Write("Enter Order Number: ");
//        string orderNo = Console.ReadLine();
//        Console.Write("Enter Delivery Address: ");
//        string address = Console.ReadLine();
//        Console.Write("Enter Order Date (yyyy-MM-dd): ");
//        DateTime orderDate = DateTime.Parse(Console.ReadLine());
//        DateTime deliveryDate = orderDate.AddDays(3);
//        Console.WriteLine("\n Order Confirmation Email:\n");
//        Console.WriteLine(GenerateEmail(name, orderNo, address, orderDate, deliveryDate));

//        // 13. Shipping Cost
//        Console.Write("\nEnter Courier ID to calculate shipping cost: ");
//        int courierId = int.Parse(Console.ReadLine());

//        string fetchQuery = "SELECT SenderAddress, ReceiverAddress, Weight FROM Courier WHERE CourierID = @cid";

//        using (SqlCommand cmd = new SqlCommand(fetchQuery, con))
//        {
//            cmd.Parameters.AddWithValue("@cid", courierId);

//            SqlDataReader reader = cmd.ExecuteReader();

//            if (reader.Read())
//            {
//                string senderAddress = reader["SenderAddress"].ToString();
//                string receiverAddress = reader["ReceiverAddress"].ToString();
//                double weight = Convert.ToDouble(reader["Weight"]);

//                reader.Close();

//                // Simulated distance based on input
//                Console.WriteLine($"\nSender: {senderAddress}");
//                Console.WriteLine($"Receiver: {receiverAddress}");
//                Console.Write("Enter approximate distance (in km): ");
//                double distance = double.Parse(Console.ReadLine());

//                // Cost calculation
//                double baseRate = 5.0;
//                double distanceRate = 2.0; // ₹ per km
//                double weightRate = 3.0;   // ₹ per kg
//                double cost = baseRate + (distance * distanceRate) + (weight * weightRate);

//                Console.WriteLine($"\n Shipping Cost for Courier ID {courierId}: ₹{cost:F2}");
//            }
//            else
//            {
//                Console.WriteLine(" Invalid Courier ID. No such courier found.");
//            }
//        }


//        // 14. Password Generator
//        Console.Write("\nEnter desired password length: ");
//        int length = int.Parse(Console.ReadLine());
//        Console.WriteLine($" Generated Password: {GeneratePassword(length)}");

//        // 15. Find Similar Addresses
//        Console.Write("\nEnter address to search: ");
//        string search = Console.ReadLine().ToLower();
//        string[] addresses = {
//            "123 Main Street",
//            "123 Main St.",
//            "456 Oak Avenue",
//            "123 main street",
//            "789 Maple Blvd"
//        };
//        bool found = false;
//        Console.WriteLine("\n Similar Addresses:");
//        foreach (string addr in addresses)
//        {
//            if (addr.ToLower().Contains(search))
//            {
//                Console.WriteLine(addr);
//                found = true;
//            }
//        }
//        if (!found)
//        {
//            Console.WriteLine(" No similar address found.");
//        }

//        con.Close();
//        Console.WriteLine("\n All tasks completed.");
//    }
//}



// //Task 5: Object-Oriented Programming – Model/Entity Classes
//using System;
//using System.Collections.Generic;
//using System.Data.SqlClient;

//namespace CourierManagementSystem
//{
//    // 1. User Class
//    public class User
//    {
//        public int UserID { get; set; }
//        public string UserName { get; set; }
//        public string Email { get; set; }
//        public string Password { get; set; }
//        public string ContactNumber { get; set; }
//        public string Address { get; set; }

//        public User() { }

//        public User(int userID, string userName, string email, string password, string contactNumber, string address)
//        {
//            UserID = userID;
//            UserName = userName;
//            Email = email;
//            Password = password;
//            ContactNumber = contactNumber;
//            Address = address;
//        }

//        public override string ToString()
//        {
//            return $"User: {UserName}, Email: {Email}, Contact: {ContactNumber}, Address: {Address}";
//        }
//    }

//    // 2. Courier Class
//    public class Courier
//    {
//        private static long trackingSeed = 100000;
//        public long CourierID { get; set; }
//        public string SenderName { get; set; }
//        public string SenderAddress { get; set; }
//        public string ReceiverName { get; set; }
//        public string ReceiverAddress { get; set; }
//        public double Weight { get; set; }
//        public string Status { get; set; }
//        public long TrackingNumber { get; private set; }
//        public DateTime DeliveryDate { get; set; }
//        public int UserID { get; set; }

//        public Courier()
//        {
//            TrackingNumber = ++trackingSeed;
//        }

//        public Courier(long courierID, string senderName, string senderAddress, string receiverName, string receiverAddress,
//                       double weight, string status, DateTime deliveryDate, int userId)
//        {
//            CourierID = courierID;
//            SenderName = senderName;
//            SenderAddress = senderAddress;
//            ReceiverName = receiverName;
//            ReceiverAddress = receiverAddress;
//            Weight = weight;
//            Status = status;
//            DeliveryDate = deliveryDate;
//            UserID = userId;
//            TrackingNumber = ++trackingSeed;
//        }

//        public override string ToString()
//        {
//            return $"Courier {TrackingNumber}: {SenderName} ➔ {ReceiverName}, Status: {Status}";
//        }
//    }

//    // 3. Employee Class
//    public class Employee
//    {
//        public int EmployeeID { get; set; }
//        public string EmployeeName { get; set; }
//        public string Email { get; set; }
//        public string ContactNumber { get; set; }
//        public string Role { get; set; }
//        public double Salary { get; set; }

//        public Employee() { }

//        public Employee(int id, string name, string email, string contact, string role, double salary)
//        {
//            EmployeeID = id;
//            EmployeeName = name;
//            Email = email;
//            ContactNumber = contact;
//            Role = role;
//            Salary = salary;
//        }

//        public override string ToString()
//        {
//            return $"Employee: {EmployeeName}, Role: {Role}, Salary: ₹{Salary}";
//        }
//    }

//    // 4. Location Class
//    public class Location
//    {
//        public int LocationID { get; set; }
//        public string LocationName { get; set; }
//        public string Address { get; set; }

//        public Location() { }

//        public Location(int id, string name, string address)
//        {
//            LocationID = id;
//            LocationName = name;
//            Address = address;
//        }

//        public override string ToString()
//        {
//            return $"Location: {LocationName}, Address: {Address}";
//        }
//    }

//    // 5. CourierCompany Class
//    public class CourierCompany
//    {
//        public string CompanyName { get; set; }
//        public List<Courier> CourierDetails { get; set; }
//        public List<Employee> EmployeeDetails { get; set; }
//        public List<Location> LocationDetails { get; set; }
//    }

//    // 6. Payment Class
//    public class Payment
//    {
//        public long PaymentID { get; set; }
//        public long CourierID { get; set; }
//        public double Amount { get; set; }
//        public DateTime PaymentDate { get; set; }

//        public override string ToString()
//        {
//            return $"Payment {PaymentID}: ₹{Amount} for Courier {CourierID} on {PaymentDate:dd MMM yyyy}";
//        }
//    }

//    // Main Method with ADO.NET logic
//    class Program
//    {
//        static void Main()
//        {
//            string connectionString = "Server=LAPTOP-D19876AQ;Initial Catalog=AssignmentDB;Integrated Security=True";
//            SqlConnection con = new SqlConnection(connectionString);
//            con.Open();

//            // Fetch and display one user
//            SqlCommand cmd = new SqlCommand("SELECT TOP 1 * FROM [User]", con);
//            SqlDataReader reader = cmd.ExecuteReader();
//            if (reader.Read())
//            {
//                User user = new User(
//                    (int)reader["UserID"],
//                    reader["Name"].ToString(),
//                    reader["Email"].ToString(),
//                    reader["Password"].ToString(),
//                    reader["ContactNumber"].ToString(),
//                    reader["Address"].ToString()
//                );
//                Console.WriteLine("User Object from DB:");
//                Console.WriteLine(user);
//            }
//            reader.Close();

//            // Fetch and display one courier
//            cmd = new SqlCommand("SELECT TOP 1 * FROM Courier", con);
//            reader = cmd.ExecuteReader();
//            if (reader.Read())
//            {
//                Courier courier = new Courier(
//                    (int)reader["CourierID"],
//                    reader["SenderName"].ToString(),
//                    reader["SenderAddress"].ToString(),
//                    reader["ReceiverName"].ToString(),
//                    reader["ReceiverAddress"].ToString(),
//                    Convert.ToDouble(reader["Weight"]),
//                    reader["Status"].ToString(),
//                    Convert.ToDateTime(reader["DeliveryDate"]),
//                    (int)reader["UserID"]
//                );
//                Console.WriteLine("\nCourier Object from DB:");
//                Console.WriteLine(courier);
//            }
//            reader.Close();

//            // Fetch and display one employee
//            cmd = new SqlCommand("SELECT TOP 1 * FROM Employee", con);
//            reader = cmd.ExecuteReader();
//            if (reader.Read())
//            {
//                Employee emp = new Employee(
//                    (int)reader["EmployeeID"],
//                    reader["Name"].ToString(),
//                    reader["Email"].ToString(),
//                    reader["ContactNumber"].ToString(),
//                    reader["Role"].ToString(),
//                    Convert.ToDouble(reader["Salary"])
//                );
//                Console.WriteLine("\nEmployee Object from DB:");
//                Console.WriteLine(emp);
//            }
//            reader.Close();

//            // Fetch and display one location
//            cmd = new SqlCommand("SELECT TOP 1 * FROM Location", con);
//            reader = cmd.ExecuteReader();
//            if (reader.Read())
//            {
//                Location loc = new Location(
//                    (int)reader["LocationID"],
//                    reader["LocationName"].ToString(),
//                    reader["Address"].ToString()
//                );
//                Console.WriteLine("\nLocation Object from DB:");
//                Console.WriteLine(loc);
//            }
//            reader.Close();

//            con.Close();
//        }
//    }
//}

//Task 6: Interface and Abstract Services with ADO.NET

//using System;
//using System.Collections.Generic;
//using System.Data;
//using System.Data.SqlClient;
//using System.Xml.Linq;

//public interface ICourierUserService
//{
//    string PlaceOrder(Courier courierObj);
//    string GetOrderStatus(string trackingNumber);
//    bool CancelOrder(string trackingNumber);
//   Courier[] GetAssignedOrder(string courierStaffName);
//}

//public interface ICourierAdminService
//{
//    int AddCourierStaff(Employee obj);
//}

//public class Courier
//{
//    private static int courierIdSeed = 1000;

//    public int CourierID { get; set; }
//    public string SenderName { get; set; }
//    public string SenderAddress { get; set; }
//    public string ReceiverName { get; set; }
//    public string ReceiverAddress { get; set; }
//    public double Weight { get; set; }
//    public string Status { get; set; }
//    public string TrackingNumber { get; set; }
//    public DateTime DeliveryDate { get; set; }
//    public DateTime CreatedDate { get; set; }
//    public int CourierStaffId { get; set; }
//    public string CourierStaffName { get; set; }
//    public int UserId { get; set; }

//    public Courier()
//    {
//        this.CourierID = ++courierIdSeed;
//        this.TrackingNumber = "TRK" + CourierID.ToString();
//        this.CreatedDate = DateTime.Now;
//    }

//    public Courier(int userId, string senderName, string senderAddress, string receiverName, string receiverAddress, double weight, string status, DateTime deliveryDate, int staffId, string staffName)
//    {
//        this.CourierID = ++courierIdSeed;
//        this.TrackingNumber = "TRK" + CourierID.ToString();
//        this.SenderName = senderName;
//        this.SenderAddress = senderAddress;
//        this.ReceiverName = receiverName;
//        this.ReceiverAddress = receiverAddress;
//        this.Weight = weight;
//        this.Status = status;
//        this.DeliveryDate = deliveryDate;
//        this.CreatedDate = DateTime.Now;
//        this.CourierStaffId = staffId;
//        this.CourierStaffName = staffName;
//        this.UserId = userId;
//    }

//    public override string ToString()
//    {
//        return $"Courier #{CourierID} [{TrackingNumber}]: {SenderName} ➔ {ReceiverName}, Staff: {CourierStaffName}, Status: {Status}";
//    }
//}


//public class Employee
//{
//    public int EmployeeID { get; set; }
//    public string Name { get; set; }
//    public string Email { get; set; }
//    public string ContactNumber { get; set; }
//    public string Role { get; set; }
//    public double Salary { get; set; }

//    public Employee() { }
//}

//public class CourierUserServiceImpl : ICourierUserService
//{
//    protected static string connectionString = "Server=LAPTOP-D19876AQ;Initial Catalog=AssignmentDB;Integrated Security=True";
//    private static int courierIdSeed = 1000;



//    public string PlaceOrder(Courier courierObj)
//    {
//        using (SqlConnection con = new SqlConnection(connectionString))
//        {
//            string tracking = courierObj.TrackingNumber;
//            string query = "INSERT INTO Courier(CourierID, SenderName, SenderAddress, ReceiverName, ReceiverAddress, Weight, Status, TrackingNumber, DeliveryDate, CreatedDate, CourierStaffId, CourierStaffName, UserID)"+
//                           "VALUES(@CourierID, @SenderName, @SenderAddress, @ReceiverName, @ReceiverAddress, @Weight, @Status, @TrackingNumber, @DeliveryDate, @CreatedDate, @CourierStaffId, @CourierStaffName, @UserID)";

//            SqlCommand cmd = new SqlCommand(query, con);
//            cmd.Parameters.AddWithValue("@CourierID", (int)courierObj.CourierID);
//            cmd.Parameters.AddWithValue("@SenderName", courierObj.SenderName);
//            cmd.Parameters.AddWithValue("@SenderAddress", courierObj.SenderAddress);
//            cmd.Parameters.AddWithValue("@ReceiverName", courierObj.ReceiverName);
//            cmd.Parameters.AddWithValue("@ReceiverAddress", courierObj.ReceiverAddress);
//            cmd.Parameters.AddWithValue("@Weight", courierObj.Weight);
//            cmd.Parameters.AddWithValue("@Status", courierObj.Status);
//            cmd.Parameters.AddWithValue("@TrackingNumber", courierObj.TrackingNumber);
//            cmd.Parameters.AddWithValue("@DeliveryDate", courierObj.DeliveryDate);
//            cmd.Parameters.AddWithValue("@CreatedDate", courierObj.CreatedDate);
//            cmd.Parameters.AddWithValue("@CourierStaffId", courierObj.CourierStaffId);
//            cmd.Parameters.AddWithValue("@CourierStaffName", courierObj.CourierStaffName);
//            cmd.Parameters.AddWithValue("@UserID", courierObj.UserId);


//            con.Open();
//            cmd.ExecuteNonQuery();
//            return tracking;
//        }
//    }

//    public string GetOrderStatus(string trackingNumber)
//    {
//        using (SqlConnection con = new SqlConnection(connectionString))
//        {
//            string query = "SELECT Status FROM Courier WHERE TrackingNumber = @TrackingNumber";
//            SqlCommand cmd = new SqlCommand(query, con);
//            cmd.Parameters.AddWithValue("@TrackingNumber", trackingNumber);
//            con.Open();
//            var status = cmd.ExecuteScalar();
//            return status != null ? status.ToString() : "Tracking number not found.";
//        }
//    }

//    public bool CancelOrder(string trackingNumber)
//    {
//        using (SqlConnection con = new SqlConnection(connectionString))
//        {
//            string checkQuery = "SELECT Status FROM Courier WHERE TrackingNumber = @TrackingNumber";
//            SqlCommand checkCmd = new SqlCommand(checkQuery, con);
//            checkCmd.Parameters.AddWithValue("@TrackingNumber", trackingNumber);
//            con.Open();
//            var status = checkCmd.ExecuteScalar();
//            if (status != null && status.ToString().ToLower() == "processing")
//            {
//                string deleteQuery = "DELETE FROM Courier WHERE TrackingNumber = @TrackingNumber";
//                SqlCommand deleteCmd = new SqlCommand(deleteQuery, con);
//                deleteCmd.Parameters.AddWithValue("@TrackingNumber", trackingNumber);
//                deleteCmd.ExecuteNonQuery();
//                return true;
//            }
//            return false;
//        }
//    }

//    public Courier[] GetAssignedOrder(string courierStaffName)
//    {
//        using (SqlConnection con = new SqlConnection(connectionString))
//        {
//            string query = "SELECT * FROM Courier WHERE CourierStaffName = @CourierStaffName";
//            SqlCommand cmd = new SqlCommand(query, con);
//            cmd.Parameters.AddWithValue("@CourierStaffName", courierStaffName);
//            con.Open();
//            SqlDataReader reader = cmd.ExecuteReader();
//            var list = new System.Collections.Generic.List<Courier>();
//            while (reader.Read())
//            {
//                Courier c = new Courier
//                {
//                    CourierID = Convert.ToInt32(reader["CourierID"]),
//                    SenderName = reader["SenderName"].ToString(),
//                    SenderAddress = reader["SenderAddress"].ToString(),
//                    ReceiverName = reader["ReceiverName"].ToString(),
//                    ReceiverAddress = reader["ReceiverAddress"].ToString(),
//                    Weight = Convert.ToDouble(reader["Weight"]),
//                    Status = reader["Status"].ToString(),
//                    TrackingNumber = reader["TrackingNumber"].ToString(),
//                    DeliveryDate = Convert.ToDateTime(reader["DeliveryDate"]),
//                    UserId = Convert.ToInt32(reader["UserID"]),
//                    CourierStaffName = reader["CourierStaffName"].ToString()
//                };
//                list.Add(c);
//            }
//            return list.ToArray();
//        }
//    }
//}

//public class CourierAdminServiceImpl : CourierUserServiceImpl, ICourierAdminService
//{
//    public int AddCourierStaff(Employee obj)
//    {
//        using (SqlConnection con = new SqlConnection(connectionString))
//        {
//            con.Open();

//            // Check if email exists
//            SqlCommand checkCmd = new SqlCommand("SELECT COUNT(*) FROM Employee WHERE Email = @Email", con);
//            checkCmd.Parameters.AddWithValue("@Email", obj.Email);
//            int exists = (int)checkCmd.ExecuteScalar();

//            if (exists > 0)
//            {
//                Console.WriteLine("Employee with this email already exists.");
//                return -1;
//            }

//            // Generate new ID
//            SqlCommand getMax = new SqlCommand("SELECT ISNULL(MAX(EmployeeID), 0) + 1 FROM Employee", con);
//            int newId = Convert.ToInt32(getMax.ExecuteScalar());
//            obj.EmployeeID = newId;

//            // Insert
//            string query = "INSERT INTO Employee (EmployeeID, Name, Email, ContactNumber, Role, Salary) " +
//                           "VALUES (@EmployeeID, @Name, @Email, @Contact, @Role, @Salary)";
//            SqlCommand cmd = new SqlCommand(query, con);
//            cmd.Parameters.AddWithValue("@EmployeeID", obj.EmployeeID);
//            cmd.Parameters.AddWithValue("@Name", obj.Name);
//            cmd.Parameters.AddWithValue("@Email", obj.Email);
//            cmd.Parameters.AddWithValue("@Contact", obj.ContactNumber);
//            cmd.Parameters.AddWithValue("@Role", obj.Role);
//            cmd.Parameters.AddWithValue("@Salary", obj.Salary);

//            cmd.ExecuteNonQuery();
//            return obj.EmployeeID;
//        }
//    }

//}

//class Program
//{
//    static void Main()
//    {
//        ICourierUserService userService = new CourierUserServiceImpl();
//        ICourierAdminService adminService = new CourierAdminServiceImpl();

//        Console.WriteLine("=== Task 6 Services (ADO.NET varchar-based, CourierStaffName) ===");

//        Courier courier = new Courier
//        {
//            SenderName = "Nidhi",
//            SenderAddress = "Hyderabad",
//            ReceiverName = "Aman",
//            ReceiverAddress = "Delhi",
//            Weight = 2.3,
//            Status = "Processing",
//            DeliveryDate = DateTime.Now.AddDays(3),
//            CourierStaffName = "Ravi",
//            UserId = 1
//        };

//        string tracking = userService.PlaceOrder(courier);
//        Console.WriteLine("Courier placed. Tracking No: " + tracking);

//        Console.WriteLine("Checking Status:");
//        Console.WriteLine(userService.GetOrderStatus(tracking));

//        Console.WriteLine("Cancel Attempt:");
//        Console.WriteLine(userService.CancelOrder(tracking) ? "Cancelled." : "Failed to cancel.");

//        Console.WriteLine("Adding Employee:");
//        Employee emp = new Employee
//        {
//            Name = "Ravi",
//            Email = "ravi@hexaware.com",
//            ContactNumber = "9876543210",
//            Role = "Delivery",
//            Salary = 25000
//        };

//        int empId = adminService.AddCourierStaff(emp);
//        Console.WriteLine("Added Employee ID: " + empId);


//        Console.WriteLine("Orders Assigned to Ravi");
//        foreach (var c in userService.GetAssignedOrder("Ravi"))
//        {
//            Console.WriteLine($" - {c.TrackingNumber}: {c.SenderName} to {c.ReceiverName}, Status: {c.Status}");
//        }
//    }
//}
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;

// TASK 7: Custom Exceptions
public class TrackingNumberNotFoundException : Exception
{
    public TrackingNumberNotFoundException(string message) : base(message) { }
}

public class InvalidEmployeeIdException : Exception
{
    public InvalidEmployeeIdException(string message) : base(message) { }
}

// Courier entity class
public class Courier
{
    public int CourierID { get; set; }
    public string SenderName { get; set; }
    public string SenderAddress { get; set; }
    public string ReceiverName { get; set; }
    public string ReceiverAddress { get; set; }
    public double Weight { get; set; }
    public string Status { get; set; }
    public string TrackingNumber { get; set; }
    public DateTime DeliveryDate { get; set; }
    public DateTime CreatedDate { get; set; }
    public int CourierStaffId { get; set; }
    public string CourierStaffName { get; set; }
    public int UserId { get; set; }
}

public class Employee
{
    public int EmployeeID { get; set; }
    public string EmployeeName { get; set; }
    public string Email { get; set; }
    public string ContactNumber { get; set; }
    public string Role { get; set; }
    public double Salary { get; set; }
}

public class Location
{
    public int LocationID { get; set; }
    public string LocationName { get; set; }
    public string Address { get; set; }
}

// TASK 8: Collections-based Company
public class CourierCompanyCollection
{
    public string CompanyName { get; set; }
    public List<Courier> Couriers { get; set; } = new List<Courier>();
    public List<Employee> Employees { get; set; } = new List<Employee>();
    public List<Location> Locations { get; set; } = new List<Location>();
}

public interface ICourierUserService
{
    string PlaceOrder(Courier courierObj);
    string GetOrderStatus(string trackingNumber);
    bool CancelOrder(string trackingNumber);
    Courier[] GetAssignedOrder(int courierStaffId);
}

public interface ICourierAdminService
{
    int AddCourierStaff(Employee obj);
}

public class CourierUserServiceCollectionImpl : ICourierUserService
{
    protected CourierCompanyCollection companyObj = new CourierCompanyCollection();

    public string PlaceOrder(Courier courierObj)
    {
        companyObj.Couriers.Add(courierObj);
        return courierObj.TrackingNumber;
    }

    public string GetOrderStatus(string trackingNumber)
    {
        foreach (var c in companyObj.Couriers)
        {
            if (c.TrackingNumber == trackingNumber)
                return c.Status;
        }
        throw new TrackingNumberNotFoundException("Tracking number not found");
    }

    public bool CancelOrder(string trackingNumber)
    {
        var item = companyObj.Couriers.Find(c => c.TrackingNumber == trackingNumber);
        if (item != null && item.Status.ToLower() == "processing")
        {
            companyObj.Couriers.Remove(item);
            return true;
        }
        return false;
    }

    public Courier[] GetAssignedOrder(int courierStaffId)
    {
        return companyObj.Couriers.FindAll(c => c.CourierStaffId == courierStaffId).ToArray();
    }
}

public class CourierAdminServiceCollectionImpl : CourierUserServiceCollectionImpl, ICourierAdminService
{
    private int nextId = 100;
    public int AddCourierStaff(Employee obj)
    {
        obj.EmployeeID = nextId++;
        companyObj.Employees.Add(obj);
        return obj.EmployeeID;
    }
}

// TASK 9: Database Connection
public class DBConnection
{
    private static SqlConnection connection;

    public static SqlConnection GetConnection()
    {
        if (connection == null)
        {
           
            string connectionString = "Server=LAPTOP-D19876AQ;Initial Catalog=AssignmentDB;Integrated Security=True";

            connection = new SqlConnection(connectionString);
        }
        return connection;
    }
}


public class CourierServiceDb
{
    private SqlConnection connection;

    public CourierServiceDb()
    {
        connection = DBConnection.GetConnection();
    }

    public void InsertCourier(Courier c)
    {
        connection.Open();

        SqlCommand getMaxIdCmd = new SqlCommand("SELECT ISNULL(MAX(CourierID), 0) + 1 FROM Courier", connection);
        int newCourierId = Convert.ToInt32(getMaxIdCmd.ExecuteScalar());
        c.CourierID = newCourierId;
        string query = "INSERT INTO Courier(CourierID, SenderName, SenderAddress, ReceiverName, ReceiverAddress, Weight, Status, TrackingNumber, DeliveryDate, CreatedDate, CourierStaffId, CourierStaffName, UserID) " +
                       "VALUES(@CourierID, @SenderName, @SenderAddress, @ReceiverName, @ReceiverAddress, @Weight, @Status, @TrackingNumber, @DeliveryDate, @CreatedDate, @CourierStaffId, @CourierStaffName, @UserID)";

        SqlCommand cmd = new SqlCommand(query, connection);
        cmd.Parameters.AddWithValue("@CourierID", c.CourierID);
        cmd.Parameters.AddWithValue("@SenderName", c.SenderName);
        cmd.Parameters.AddWithValue("@SenderAddress", c.SenderAddress);
        cmd.Parameters.AddWithValue("@ReceiverName", c.ReceiverName);
        cmd.Parameters.AddWithValue("@ReceiverAddress", c.ReceiverAddress);
        cmd.Parameters.AddWithValue("@Weight", c.Weight);
        cmd.Parameters.AddWithValue("@Status", c.Status);
        cmd.Parameters.AddWithValue("@TrackingNumber", c.TrackingNumber);
        cmd.Parameters.AddWithValue("@DeliveryDate", c.DeliveryDate);
        cmd.Parameters.AddWithValue("@CreatedDate", DateTime.Now);
        cmd.Parameters.AddWithValue("@CourierStaffId", c.CourierStaffId);
        cmd.Parameters.AddWithValue("@CourierStaffName", c.CourierStaffName);
        cmd.Parameters.AddWithValue("@UserID", c.UserId);
        cmd.ExecuteNonQuery();
        connection.Close();
    }


    public void UpdateStatus(string trackingNumber, string status)
    {
        string query = "UPDATE Courier SET Status=@Status WHERE TrackingNumber=@TrackingNumber";
        SqlCommand cmd = new SqlCommand(query, connection);
        cmd.Parameters.AddWithValue("@Status", status);
        cmd.Parameters.AddWithValue("@TrackingNumber", trackingNumber);
        connection.Open();
        cmd.ExecuteNonQuery();
        connection.Close();
    }

    public void GetDeliveryHistory(string trackingNumber)
    {
        string query = "SELECT * FROM Courier WHERE TrackingNumber = @TrackingNumber";
        SqlCommand cmd = new SqlCommand(query, connection);
        cmd.Parameters.AddWithValue("@TrackingNumber", trackingNumber);
        connection.Open();
        SqlDataReader reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            Console.WriteLine($"{reader["SenderName"]} to {reader["ReceiverName"]} - Status: {reader["Status"]}");
        }
        reader.Close();
        connection.Close();
    }

    public void GenerateShipmentReport()
    {
        string query = "SELECT Status, COUNT(*) AS Count FROM Courier GROUP BY Status";
        SqlCommand cmd = new SqlCommand(query, connection);
        connection.Open();
        SqlDataReader reader = cmd.ExecuteReader();
        Console.WriteLine("Shipment Status Report:");
        while (reader.Read())
        {
            Console.WriteLine($"{reader["Status"]}: {reader["Count"]}");
        }
        reader.Close();
        connection.Close();
    }

    public void GenerateRevenueReport()
    {
        string query = "SELECT SUM(Amount) FROM Payment";
        SqlCommand cmd = new SqlCommand(query, connection);
        connection.Open();
        var revenue = cmd.ExecuteScalar();
        Console.WriteLine("Total Revenue: ₹" + revenue);
        connection.Close();
    }
}
public class Program
{
    public static void Main()
    {
        try
        {
            CourierServiceDb service = new CourierServiceDb();

            Courier c = new Courier
            {
                SenderName = "Nidhi",
                SenderAddress = "Hyderabad",
                ReceiverName = "Neha",
                ReceiverAddress = "Delhi",
                Weight = 2.5,
                Status = "Processing",
                TrackingNumber = "TRK001",
                DeliveryDate = DateTime.Now.AddDays(3),
                CourierStaffId = 101,
                CourierStaffName = "Ravi",
                UserId = 1
            };

            Console.WriteLine("Inserting Courier...");
            service.InsertCourier(c);

            Console.WriteLine("\nUpdating Status...");
            service.UpdateStatus("TRK001", "Delivered");

            Console.WriteLine("\nDelivery History:");
            service.GetDeliveryHistory("TRK001");

            Console.WriteLine("\nShipment Report:");
            service.GenerateShipmentReport();

            Console.WriteLine("\nRevenue Report:");
            service.GenerateRevenueReport();
        }
        catch (TrackingNumberNotFoundException ex)
        {
            Console.WriteLine("Custom Exception: " + ex.Message);
        }
        catch (InvalidEmployeeIdException ex)
        {
            Console.WriteLine("Custom Exception: " + ex.Message);
        }
        catch (Exception ex)
        {
            Console.WriteLine("General Error: " + ex.Message);
        }
    }
}




























